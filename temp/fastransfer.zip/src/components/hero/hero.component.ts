import { Component, ChangeDetectionStrategy, output, signal, ElementRef, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { DatePickerComponent } from '../date-picker/date-picker.component';

@Component({
  selector: 'app-hero',
  standalone: true,
  imports: [AnimateOnScrollDirective, TranslatePipe, ReactiveFormsModule, DatePickerComponent],
  templateUrl: './hero.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeroComponent {
  private readonly elementRef = inject(ElementRef<HTMLElement>);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly fb = inject(FormBuilder);
  
  readonly openBookingModal = output<{ destination: string; date: string }>();
  
  readonly quickBookingForm = this.fb.group({
    from: [{ value: 'Bratislava', disabled: true }, Validators.required],
    to: ['', Validators.required],
    date: ['', Validators.required],
  });

  readonly heroTransform = signal('perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)');

  isFieldInvalid(fieldName: string): boolean {
    const control = this.quickBookingForm.get(fieldName);
    return !!control && control.invalid && control.touched;
  }
  
  onQuickBook(): void {
    if (this.quickBookingForm.invalid) {
      this.quickBookingForm.markAllAsTouched();
      return;
    }
    const { to, date } = this.quickBookingForm.getRawValue();
    if (to && date) {
        this.openBookingModal.emit({ destination: to, date });
    }
  }

  onMouseMove(event: MouseEvent): void {
    if (!isPlatformBrowser(this.platformId)) return;

    const rect = this.elementRef.nativeElement.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const { width, height } = rect;
    // Calculate rotation based on mouse position relative to the element center
    // The multiplication factor determines the max rotation angle (e.g., -5 to +5 degrees)
    const rotateX = ((y / height) - 0.5) * -10; 
    const rotateY = ((x / width) - 0.5) * 10;

    this.heroTransform.set(`perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.05)`);
  }

  onMouseLeave(): void {
    // Reset transform when mouse leaves the element
    this.heroTransform.set('perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)');
  }
}