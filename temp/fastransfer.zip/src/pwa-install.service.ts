import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PwaInstallService {
  private installPromptEvent: any = null;
  readonly canInstall = signal(false);

  constructor() {
    window.addEventListener('beforeinstallprompt', (event) => {
      // Prevent the mini-infobar from appearing on mobile
      event.preventDefault();
      // Stash the event so it can be triggered later.
      this.installPromptEvent = event;
      // Update UI to notify the user they can add to home screen
      this.canInstall.set(true);
    });
  }

  promptToInstall(): void {
    if (!this.installPromptEvent) {
      return;
    }
    // Show the install prompt
    this.installPromptEvent.prompt();
    // Wait for the user to respond to the prompt
    this.installPromptEvent.userChoice.then(({ outcome }: { outcome: 'accepted' | 'dismissed' }) => {
      console.log(`User response to the install prompt: ${outcome}`);
      // We've used the prompt, and can't use it again, throw it away
      this.installPromptEvent = null;
      this.canInstall.set(false);
    });
  }
}
