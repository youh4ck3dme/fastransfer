import { Directive, ElementRef, inject, AfterViewInit, OnDestroy } from '@angular/core';

@Directive({
  selector: '[appTrapFocus]',
  standalone: true,
})
export class TrapFocusDirective implements AfterViewInit, OnDestroy {
  private readonly elementRef = inject(ElementRef<HTMLElement>);
  private firstFocusableElement!: HTMLElement;
  private lastFocusableElement!: HTMLElement;

  private handleKeyDown = (event: KeyboardEvent): void => {
    if (event.key !== 'Tab') {
      return;
    }

    if (event.shiftKey) { // Shift + Tab
      if (document.activeElement === this.firstFocusableElement) {
        this.lastFocusableElement.focus();
        event.preventDefault();
      }
    } else { // Tab
      if (document.activeElement === this.lastFocusableElement) {
        this.firstFocusableElement.focus();
        event.preventDefault();
      }
    }
  };

  ngAfterViewInit(): void {
    // FIX: The generic type argument on querySelectorAll can cause issues in some environments. Using a type assertion on the result is a safer alternative.
    const focusableElements = this.elementRef.nativeElement.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    ) as NodeListOf<HTMLElement>;
    
    if (focusableElements.length > 0) {
      this.firstFocusableElement = focusableElements[0];
      this.lastFocusableElement = focusableElements[focusableElements.length - 1];
      
      // Defer focus to allow for animations and rendering to complete.
      setTimeout(() => this.firstFocusableElement.focus(), 50);

      this.elementRef.nativeElement.addEventListener('keydown', this.handleKeyDown);
    }
  }

  ngOnDestroy(): void {
    this.elementRef.nativeElement.removeEventListener('keydown', this.handleKeyDown);
  }
}
