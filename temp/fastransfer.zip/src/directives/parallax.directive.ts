import { Directive, ElementRef, inject, OnInit, OnDestroy, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Directive({
  selector: '[appParallax]',
  standalone: true,
})
export class ParallaxDirective implements OnInit, OnDestroy {
  private readonly elementRef = inject(ElementRef<HTMLElement>);
  private readonly platformId = inject(PLATFORM_ID);
  private ticking = false;

  private readonly handleScroll = (): void => {
    if (!this.ticking) {
      window.requestAnimationFrame(() => {
        this.updateParallax();
        this.ticking = false;
      });
      this.ticking = true;
    }
  };

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      window.addEventListener('scroll', this.handleScroll, { passive: true });
      // Initial call to set position before any scrolling
      this.updateParallax();
    }
  }

  ngOnDestroy(): void {
    if (isPlatformBrowser(this.platformId)) {
      window.removeEventListener('scroll', this.handleScroll);
    }
  }

  private updateParallax(): void {
    const rect = this.elementRef.nativeElement.getBoundingClientRect();
    const viewportHeight = window.innerHeight;

    // Calculate how far the element's top is from the bottom of the viewport, as a percentage of total scroll travel (viewport + element height)
    const scrollPercent = (viewportHeight - rect.top) / (viewportHeight + rect.height);
    
    // Clamp the value between 0 and 1 for predictable CSS behavior
    const clampedPercent = Math.max(0, Math.min(1, scrollPercent));

    this.elementRef.nativeElement.style.setProperty('--scroll-percentage', clampedPercent.toString());
  }
}
