import { Component, ChangeDetectionStrategy } from '@angular/core';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { NgOptimizedImage } from '@angular/common';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { ParallaxDirective } from '../../directives/parallax.directive';

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [AnimateOnScrollDirective, NgOptimizedImage, TranslatePipe, ParallaxDirective],
  templateUrl: './about-us.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AboutUsComponent {}