import { Injectable, signal, computed } from '@angular/core';
import { dictionary } from '../i18n';

export type Language = 'sk' | 'en' | 'de';

interface Flag {
    width: number;
    height: number;
    viewBox: string;
    path: string;
}

interface LanguageOption {
    code: Language;
    name: string;
    flag: Flag;
}

@Injectable({
  providedIn: 'root'
})
export class TranslationService {
  readonly currentLang = signal<Language>('sk');
  
  readonly languages: LanguageOption[] = [
      { code: 'sk', name: 'Slovenčina', flag: { width: 20, height: 15, viewBox: '0 0 20 15', path: '<rect width="20" height="15" fill="#fff"/><rect width="20" height="10" fill="#0b4ea2"/><rect width="20" height="5" fill="#ee1c25"/><path d="M6 7.5a2.5 2.5 0 00-2.5 2.5H2v-1h1.5a1.5 1.5 0 013 0v1H8v-1h-.5a2.5 2.5 0 00-1.5-2.236V5h-1v2.264A2.5 2.5 0 006 7.5zm.5 0a1.5 1.5 0 011.5 1.5v1h-3v-1a1.5 1.5 0 011.5-1.5z" fill="#ee1c25"/>'} },
      { code: 'en', name: 'English', flag: { width: 20, height: 15, viewBox: '0 0 60 30', path: '<clipPath id="a"><path d="M0 0v30h60V0z"/></clipPath><path d="M0 0v30h60V0z" fill="#012169"/><path d="M0 0l60 30m0-30L0 30" stroke="#fff" stroke-width="6" clip-path="url(#a)"/><path d="M0 0l60 30m0-30L0 30" stroke="#C8102E" stroke-width="4" clip-path="url(#a)"/><path d="M30 0v30M0 15h60" stroke="#fff" stroke-width="10" clip-path="url(#a)"/><path d="M30 0v30M0 15h60" stroke="#C8102E" stroke-width="6" clip-path="url(#a)"/>'} },
      { code: 'de', name: 'Deutsch', flag: { width: 20, height: 15, viewBox: '0 0 5 3', path: '<path d="M0 0h5v3H0z"/><path d="M0 1h5v2H0z" fill="#D00"/><path d="M0 2h5v1H0z" fill="#FFCE00"/>'} }
  ];

  private translations = computed(() => dictionary[this.currentLang()]);

  changeLanguage(lang: Language): void {
    this.currentLang.set(lang);
  }

  translate(key: string, params?: Record<string, string | number>): string {
    let translation = this.translations()[key] || key;
    if (params) {
      Object.keys(params).forEach(paramKey => {
        translation = translation.replace(`\${${paramKey}}`, String(params[paramKey]));
      });
    }
    return translation;
  }
}