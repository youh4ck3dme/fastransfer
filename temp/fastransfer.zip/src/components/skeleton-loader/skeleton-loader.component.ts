import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-skeleton-loader',
  standalone: true,
  template: `
    <section class="w-full h-96 flex items-center justify-center scroll-mt-20" aria-live="polite" aria-label="Loading section content">
      <div class="w-full max-w-4xl mx-auto p-4">
        <div class="animate-pulse w-full">
          <div class="h-8 bg-gray-200 dark:bg-gray-700 rounded-md w-1/2 mb-6"></div>
          <div class="space-y-4">
            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-full"></div>
            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-5/6"></div>
            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-full"></div>
            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-3/4"></div>
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SkeletonLoaderComponent {}
