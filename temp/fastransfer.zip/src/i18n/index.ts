import { sk } from './sk';
import { en } from './en';
import { de } from './de';
import { Language } from '../services/translation.service';

export const dictionary: Record<Language, Record<string, string>> = {
  sk,
  en,
  de,
};
