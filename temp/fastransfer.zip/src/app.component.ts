import { Component, ChangeDetectionStrategy, signal, OnInit, effect, PLATFORM_ID, inject, Renderer2, Signal } from '@angular/core';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';
import { Title } from '@angular/platform-browser';
import { toSignal } from '@angular/core/rxjs-interop';
import { fromEvent } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ServicesComponent } from './components/services/services.component';
import { PricingComponent } from './components/pricing/pricing.component';
import { OfflineBannerComponent } from './components/offline-banner/offline-banner.component';
import { InstallPromptComponent } from './components/install-prompt/install-prompt.component';
import { ToastComponent } from './components/toast/toast.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { AnimateOnScrollDirective } from './directives/animate-on-scroll.directive';
import { CorporateCooperationComponent } from './components/corporate-cooperation/corporate-cooperation.component';
import { CookieConsentComponent } from './components/cookie-consent/cookie-consent.component';
import { BookingModalComponent } from './components/booking-modal/booking-modal.component';
import { FleetComponent } from './components/fleet/fleet.component';
import { FaqComponent } from './components/faq/faq.component';
import { HeroComponent } from './components/hero/hero.component';
import { BenefitsComponent } from './components/benefits/benefits.component';
import { ContactInfoComponent } from './components/contact-info/contact-info.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { TestimonialsComponent } from './components/testimonials/testimonials.component';
import { PrivacyPolicyModalComponent } from './components/privacy-policy-modal/privacy-policy-modal.component';
import { TranslatePipe } from './pipes/translate.pipe';
import { TranslationService } from './services/translation.service';
import { BookingDetails } from './gemini.service';
import { SkeletonLoaderComponent } from './components/skeleton-loader/skeleton-loader.component';
import { BlogComponent } from './components/blog/blog.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    NavbarComponent,
    ServicesComponent,
    PricingComponent,
    OfflineBannerComponent,
    InstallPromptComponent,
    ToastComponent,
    WelcomeComponent,
    AnimateOnScrollDirective,
    CorporateCooperationComponent,
    CookieConsentComponent,
    BookingModalComponent,
    FleetComponent,
    FaqComponent,
    HeroComponent,
    BenefitsComponent,
    ContactInfoComponent,
    AboutUsComponent,
    TestimonialsComponent,
    PrivacyPolicyModalComponent,
    TranslatePipe,
    SkeletonLoaderComponent,
    BlogComponent,
  ],
})
export class AppComponent implements OnInit {
  isLoading = signal(true);
  isContentLoaded = signal(false);
  isBookingModalOpen = signal(false);
  isPrivacyModalOpen = signal(false);
  initialBookingDetails = signal<Partial<BookingDetails> | null>(null);
  
  theme = signal<'light' | 'dark'>('light');
  showScrollToTop: Signal<boolean>;
  currentView = signal<'main' | 'blog'>('main');
  
  private readonly platformId = inject(PLATFORM_ID);
  private readonly document = inject(DOCUMENT);
  private readonly renderer = inject(Renderer2);
  private readonly titleService = inject(Title);
  private readonly translationService = inject(TranslationService);

  constructor() {
    // Effect for theme management
    effect(() => {
      if (this.theme() === 'dark') {
        this.renderer.addClass(this.document.documentElement, 'dark');
      } else {
        this.renderer.removeClass(this.document.documentElement, 'dark');
      }
    });

    // Effect for dynamic language and title updates (SEO & Accessibility)
    effect(() => {
      const lang = this.translationService.currentLang();
      this.renderer.setAttribute(this.document.documentElement, 'lang', lang);
      const title = this.translationService.translate('document.title');
      this.titleService.setTitle(title);
    });

    // Signal for scroll-to-top button visibility
    if (isPlatformBrowser(this.platformId)) {
      this.showScrollToTop = toSignal(
        fromEvent(window, 'scroll').pipe(
          map(() => window.scrollY > window.innerHeight * 0.8),
          startWith(false)
        ),
        { initialValue: false }
      );
    } else {
      this.showScrollToTop = signal(false);
    }
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      const storedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (storedTheme) {
        this.theme.set(storedTheme);
      } else if (prefersDark) {
        this.theme.set('dark');
      }
    }

    setTimeout(() => {
      this.isLoading.set(false);
      // Use another timeout to trigger the content fade-in animation after the splash screen fade-out starts
      setTimeout(() => this.isContentLoaded.set(true), 50);
    }, 3000); // 2s progress bar + 0.5s fade-out + 0.5s buffer
  }

  toggleTheme(): void {
    this.theme.update(current => {
      const newTheme = current === 'light' ? 'dark' : 'light';
      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('theme', newTheme);
      }
      return newTheme;
    });
  }

  openBookingModal(details?: Partial<BookingDetails>): void {
    if (details) {
      this.initialBookingDetails.set(details);
    }
    this.isBookingModalOpen.set(true);
  }

  closeBookingModal(): void {
    this.isBookingModalOpen.set(false);
    this.initialBookingDetails.set(null);
  }

  openPrivacyModal(): void {
    this.isPrivacyModalOpen.set(true);
  }

  closePrivacyModal(): void {
    this.isPrivacyModalOpen.set(false);
  }

  scrollToTop(): void {
    if (isPlatformBrowser(this.platformId)) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
  
  showBlog(): void {
    this.currentView.set('blog');
    this.scrollToTop();
  }

  showMain(): void {
    this.currentView.set('main');
  }
}
