import { Injectable, signal, effect, Inject, PLATFORM_ID, Renderer2, RendererFactory2, computed } from '@angular/core';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';

type ConsentStatus = 'pending' | 'accepted' | 'declined';

@Injectable({
  providedIn: 'root'
})
export class CookieService {
  private readonly storageKey = 'fasTransferCookieConsent';
  private readonly renderer: Renderer2;
  private readonly consentStatus = signal<ConsentStatus>('pending');
  
  readonly showBanner = computed(() => this.consentStatus() === 'pending');

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    @Inject(DOCUMENT) private document: Document,
    rendererFactory: RendererFactory2
  ) {
    this.renderer = rendererFactory.createRenderer(null, null);
    if (isPlatformBrowser(this.platformId)) {
      const storedStatus = localStorage.getItem(this.storageKey) as ConsentStatus | null;
      this.consentStatus.set(storedStatus || 'pending');
    }

    // Effect to run analytics when consent is given
    effect(() => {
      if (this.consentStatus() === 'accepted') {
        this.enableAnalyticsScripts();
      }
    });
  }

  accept(): void {
    this.consentStatus.set('accepted');
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(this.storageKey, 'accepted');
    }
  }

  decline(): void {
    this.consentStatus.set('declined');
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(this.storageKey, 'declined');
    }
  }
  
  private enableAnalyticsScripts(): void {
    if (isPlatformBrowser(this.platformId)) {
      const scripts = this.document.querySelectorAll('script[type="text/plain"][data-cookie-consent="accepted"]');
      scripts.forEach(script => {
        const newScript = this.renderer.createElement('script');
        
        // Copy attributes from placeholder to new script
        for (const attr of Array.from(script.attributes)) {
          if (attr.name !== 'type') { // Don't copy type, as it's being changed
             this.renderer.setAttribute(newScript, attr.name, attr.value);
          }
        }
        
        newScript.text = script.textContent || ''; // Copy inline script content
        
        this.renderer.setAttribute(newScript, 'type', 'text/javascript');

        // Replace placeholder with the new, executable script
        script.parentNode?.replaceChild(newScript, script);
      });
    }
  }
}
