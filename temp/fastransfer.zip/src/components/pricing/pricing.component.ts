import { Component, ChangeDetectionStrategy, output, signal, computed, inject } from '@angular/core';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { TranslationService } from '../../services/translation.service';
import { cityRoutes, airportRoutes, RouteOption } from '../../data/routes';

@Component({
  selector: 'app-pricing',
  standalone: true,
  imports: [AnimateOnScrollDirective, TranslatePipe],
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PricingComponent {
  private readonly translationService = inject(TranslationService);
  
  openBookingModal = output<{ transferType: 'city' | 'airport', routeValue: string }>();
  activeTab = signal<'city' | 'airport'>('airport');

  readonly cityDescription = computed(() => this.translationService.translate('pricing.description.city'));
  readonly airportDescription = computed(() => this.translationService.translate('pricing.description.airport'));
  
  readonly cityTransfers: RouteOption[] = cityRoutes;

  readonly airportTransfers: RouteOption[] = airportRoutes;

  setActiveTab(tab: 'city' | 'airport'): void {
    this.activeTab.set(tab);
  }
}