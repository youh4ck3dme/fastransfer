import { Component, ChangeDetectionStrategy, signal, inject, effect, input, computed } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { startWith } from 'rxjs/operators';
import { cityRoutes, airportRoutes, RouteOption } from '../../data/routes';
import { NetworkStatusService } from '../../network-status.service';
import { NotificationService } from '../../notification.service';
import { DatePickerComponent } from '../date-picker/date-picker.component';
import { TimePickerComponent } from '../time-picker/time-picker.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { TranslationService } from '../../services/translation.service';
import { GeminiService, BookingDetails } from '../../gemini.service';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';
import { SafePipe } from '../../pipes/safe.pipe';
import { CalendarService, CalendarEvent } from '../../services/calendar.service';
import { SafeResourceUrl } from '@angular/platform-browser';

// Custom validator for email
function customEmailValidator(control: AbstractControl): ValidationErrors | null {
  const value = control.value;
  if (!value) {
    return null; // Let 'required' handle empty value
  }
  if (!value.includes('@')) {
    return { missingAtSymbol: true };
  }
  if (value.includes('@') && value.split('@')[1].length === 0) {
      return { missingDomain: true };
  }
  if (value.includes('@') && !value.split('@')[1].includes('.')) {
    return { missingDomain: true };
  }
  // A simple regex to catch most other invalid formats
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
    return { invalidFormat: true };
  }
  return null;
}


@Component({
  selector: 'app-booking-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DatePickerComponent, TimePickerComponent, TranslatePipe, ConfirmationModalComponent, SafePipe],
  templateUrl: './booking-form.component.html',
  styleUrls: ['./booking-form.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BookingFormComponent {
  private readonly fb = inject(FormBuilder);
  private readonly networkStatusService = inject(NetworkStatusService);
  private readonly notificationService = inject(NotificationService);
  private readonly translationService = inject(TranslationService);
  private readonly geminiService = inject(GeminiService);
  private readonly calendarService = inject(CalendarService);

  readonly initialDetails = input<Partial<BookingDetails> | null>(null);
  readonly isLoading = signal(false);
  readonly isAiLoading = signal(false);
  readonly isOnline = this.networkStatusService.isOnline;
  readonly availableRoutes = signal<RouteOption[]>([]);
  
  readonly isConfirmationOpen = signal(false);
  readonly confirmationData = signal<any | null>(null);
  
  readonly bookingStatus = signal<'idle' | 'success'>('idle');
  readonly lastBookingDetails = signal<any | null>(null);

  readonly bookingForm: FormGroup = this.fb.group({
    aiPrompt: [''],
    date: ['', Validators.required],
    time: ['', Validators.required],
    transferType: ['', Validators.required],
    route: [{ value: '', disabled: true }, Validators.required],
    passengers: ['', Validators.required],
    name: ['', Validators.required],
    email: ['', [Validators.required, customEmailValidator]],
    phone: ['', [Validators.required, Validators.pattern(/^\+?\d{1,3}?[-.\s]?\(?\d{1,4}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/)]],
  });

  private readonly transferTypeValue = toSignal(
    this.bookingForm.get('transferType')!.valueChanges.pipe(
      startWith(this.bookingForm.get('transferType')!.value)
    )
  );

  constructor() {
    // Effect to handle dependent dropdown logic
    effect(() => {
      const type = this.transferTypeValue();
      const routeControl = this.bookingForm.get('route');

      // Do not reset route if it's being patched from initialDetails
      const details = this.initialDetails();
      if (!details || details.transferType !== type) {
        routeControl?.reset('');
      }

      if (type === 'city') {
        this.availableRoutes.set(cityRoutes);
        routeControl?.enable();
      } else if (type === 'airport') {
        this.availableRoutes.set(airportRoutes);
        routeControl?.enable();
      } else {
        this.availableRoutes.set([]);
        routeControl?.disable();
      }
    });

    // Effect for pre-filling the form from the pricing table
    effect(() => {
        const details = this.initialDetails();
        if (details && (details.transferType || details.routeValue)) {
            this.bookingForm.patchValue({
                transferType: details.transferType,
                route: details.routeValue
            });
            this.bookingForm.get('transferType')?.markAsTouched();
            this.bookingForm.get('route')?.markAsTouched();
        }
    }, { allowSignalWrites: true });

    // Effect for triggering AI from the Hero form
    effect(() => {
        const details = this.initialDetails();
        if (details && details.destination && details.date) {
            const prompt = this.translationService.translate('ai.promptTemplate', {
              destination: details.destination,
              date: details.date
            });
            this.bookingForm.patchValue({ aiPrompt: prompt });
            this.fillWithAi();
        }
    }, { allowSignalWrites: true });
  }

  isFieldInvalid(fieldName: string): boolean {
    const control = this.bookingForm.get(fieldName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  async fillWithAi(): Promise<void> {
    const prompt = this.bookingForm.get('aiPrompt')?.value;
    if (!prompt) return;

    if (!this.geminiService.isAvailable()) {
      this.notificationService.show(this.translationService.translate('notification.ai.noApiKey'), 'error');
      return;
    }
    
    this.isAiLoading.set(true);
    try {
      const details = await this.geminiService.getBookingDetailsFromText(prompt);
      
      // Patch values. The effect will handle enabling/disabling the route dropdown.
      this.bookingForm.patchValue({
        date: details.date,
        time: details.time,
        transferType: details.transferType,
        route: details.routeValue,
        passengers: details.passengers
      });
      
      // Ensure controls are marked as touched to show validation state
      this.bookingForm.get('date')?.markAsTouched();
      this.bookingForm.get('time')?.markAsTouched();
      this.bookingForm.get('transferType')?.markAsTouched();
      this.bookingForm.get('route')?.markAsTouched();
      this.bookingForm.get('passengers')?.markAsTouched();

      this.notificationService.show(this.translationService.translate('notification.ai.success'), 'success');

    } catch (error) {
      console.error('Error processing AI request:', error);
      this.notificationService.show(this.translationService.translate('notification.ai.error'), 'error');
    } finally {
      this.isAiLoading.set(false);
    }
  }

  onSubmit(): void {
    if (this.bookingForm.invalid) {
      this.bookingForm.markAllAsTouched();
      this.notificationService.show(this.translationService.translate('notification.form.error'), 'error');
      return;
    }

    const formData = this.bookingForm.value;
    const allRoutes = [...cityRoutes, ...airportRoutes];
    const selectedRoute = allRoutes.find(r => r.value === formData.route);
    const routeLabel = selectedRoute ? selectedRoute.label : 'N/A';
    const typeLabel = formData.transferType === 'airport' 
        ? this.translationService.translate('bookingForm.options.airport') 
        : this.translationService.translate('bookingForm.options.city');

    this.confirmationData.set({
      ...formData,
      routeLabel,
      typeLabel
    });
    this.isConfirmationOpen.set(true);
  }
  
  async executeSubmit(): Promise<void> {
    const formData = this.confirmationData();
    this.isConfirmationOpen.set(false);
    
    if (!this.isOnline()) {
        this.notificationService.show(this.translationService.translate('notification.form.offline'), 'error');
        return;
    }

    this.isLoading.set(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    this.isLoading.set(false);
    this.lastBookingDetails.set(formData);
    this.bookingStatus.set('success');
  }

  cancelConfirmation(): void {
    this.isConfirmationOpen.set(false);
    this.confirmationData.set(null);
  }

  bookAnotherRide(): void {
    this.bookingForm.reset({
        aiPrompt: '',
        transferType: ''
    });
    Object.keys(this.bookingForm.controls).forEach(key => {
        this.bookingForm.get(key)?.markAsPristine();
        this.bookingForm.get(key)?.markAsUntouched();
    });
    this.lastBookingDetails.set(null);
    this.confirmationData.set(null);
    this.bookingStatus.set('idle');
  }


  clearForm(): void {
    this.bookAnotherRide();
    this.notificationService.show(this.translationService.translate('notification.form.cleared'), 'success');
  }
  
  async shareBooking(): Promise<void> {
    if (this.bookingForm.invalid) {
      this.notificationService.show(this.translationService.translate('notification.share.error.formInvalid'), 'error');
      return;
    }

    const { name, date, time, transferType, route, passengers } = this.bookingForm.value;
    const selectedRoute = [...cityRoutes, ...airportRoutes].find(r => r.value === route);
    
    const typeLabel = transferType === 'airport' 
        ? this.translationService.translate('bookingForm.options.airport') 
        : this.translationService.translate('bookingForm.options.city');
    const priceInfo = selectedRoute?.price ? selectedRoute.price : 'Na vyžiadanie';
    
    const shareText = this.translationService.translate('share.textTemplate', {
      name,
      date,
      time,
      typeLabel,
      routeLabel: selectedRoute?.label || 'N/A',
      priceInfo,
      passengers
    });

    const shareData = {
      title: this.translationService.translate('share.title'),
      text: shareText,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        this.notificationService.show(this.translationService.translate('notification.share.success'), 'success');
      } else {
        this.notificationService.show(this.translationService.translate('notification.share.error.unsupported'), 'error');
      }
    } catch (err) {
      console.error('Error sharing:', err);
      // Don't show an error if user cancels the share dialog
      if ((err as Error).name !== 'AbortError') {
          this.notificationService.show(this.translationService.translate('notification.share.error.general'), 'error');
      }
    }
  }
  
  private createCalendarEvent(details: any): CalendarEvent {
    const startTime = new Date(`${details.date}T${details.time}`);
    
    // Estimate end time: 2 hours for airport, 1 hour for city
    const durationHours = details.transferType === 'airport' ? 2 : 1;
    const endTime = new Date(startTime.getTime() + durationHours * 60 * 60 * 1000);

    const description = this.translationService.translate('share.textTemplate', {
      name: details.name,
      date: details.date,
      time: details.time,
      typeLabel: details.typeLabel,
      routeLabel: details.routeLabel,
      priceInfo: 'Potvrdené',
      passengers: details.passengers
    });

    return {
      startTime,
      endTime,
      title: `FasTransfer: ${details.routeLabel}`,
      description,
      location: details.routeLabel
    };
  }

  readonly calendarEvent = computed(() => {
    const details = this.lastBookingDetails();
    return details ? this.createCalendarEvent(details) : null;
  });

  readonly googleCalendarLink = computed(() => {
    const event = this.calendarEvent();
    return event ? this.calendarService.createGoogleCalendarLink(event) : '';
  });

  readonly icsCalendarLink = computed<SafeResourceUrl | ''>(() => {
    const event = this.calendarEvent();
    return event ? this.calendarService.createIcsFileUrl(event) : '';
  });
}