export interface BlogPost {
  id: string;
  titleKey: string;
  publishedDate: string; // YYYY-MM-DD
  imageUrl: string;
  excerptKey: string;
  contentKey: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: 'tipy-vylet-vieden',
    titleKey: 'blog.posts.viennaTrip.title',
    publishedDate: '2024-07-15',
    imageUrl: 'https://images.unsplash.com/photo-1599935397891-2283b9a7f339?w=800&h=500&fit=crop',
    excerptKey: 'blog.posts.viennaTrip.excerpt',
    contentKey: 'blog.posts.viennaTrip.content',
  },
  {
    id: 'priprava-sluzobna-cesta',
    titleKey: 'blog.posts.businessTrip.title',
    publishedDate: '2024-07-08',
    imageUrl: 'https://images.unsplash.com/photo-1560264280-984edb7570a1?w=800&h=500&fit=crop',
    excerptKey: 'blog.posts.businessTrip.excerpt',
    contentKey: 'blog.posts.businessTrip.content',
  },
  {
    id: 'vyhody-vip-prepravy',
    titleKey: 'blog.posts.vipBenefits.title',
    publishedDate: '2024-06-29',
    imageUrl: 'https://images.unsplash.com/photo-1626397223244-a95c522a0f8e?w=800&h=500&fit=crop',
    excerptKey: 'blog.posts.vipBenefits.excerpt',
    contentKey: 'blog.posts.vipBenefits.content',
  },
];
