import { Injectable, inject } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

export interface CalendarEvent {
  title: string;
  description: string;
  location: string;
  startTime: Date;
  endTime: Date;
}

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  private readonly sanitizer = inject(DomSanitizer);

  private formatDate(date: Date): string {
    return date.toISOString().replace(/-|:|\.\d{3}/g, '');
  }

  createGoogleCalendarLink(event: CalendarEvent): string {
    const format = (d: Date) => this.formatDate(d);
    const baseUrl = 'https://www.google.com/calendar/render?action=TEMPLATE';
    const params = new URLSearchParams({
      text: event.title,
      dates: `${format(event.startTime)}/${format(event.endTime)}`,
      details: event.description,
      location: event.location
    });
    return `${baseUrl}&${params.toString()}`;
  }

  createIcsFileUrl(event: CalendarEvent): SafeResourceUrl {
    const format = (d: Date) => this.formatDate(d);
    const uid = `${Date.now()}@fastransfer.sk`;
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'BEGIN:VEVENT',
      `UID:${uid}`,
      `DTSTAMP:${format(new Date())}`,
      `DTSTART:${format(event.startTime)}`,
      `DTEND:${format(event.endTime)}`,
      `SUMMARY:${event.title}`,
      `DESCRIPTION:${event.description.replace(/\n/g, '\\n')}`,
      `LOCATION:${event.location}`,
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
