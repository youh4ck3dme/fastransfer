import { describe, it, expect, beforeEach, jest } from '@jest/globals';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { By } from '@angular/platform-browser';
import { provideServiceWorker } from '@angular/service-worker';
import { DebugElement } from '@angular/core';

describe('App E2E Tests', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(fakeAsync(async () => {
    await TestBed.configureTestingModule({
      imports: [AppComponent, NoopAnimationsModule],
      providers: [
        provideHttpClient(),
        provideServiceWorker('ngsw-worker.js', { enabled: false }),
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    
    // Initial loading sequence
    fixture.detectChanges(); // ngOnInit
    tick(3000); // Wait for splash screen
    fixture.detectChanges(); 
    tick(50); // Wait for content fade-in
    fixture.detectChanges();
  }));

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });
  
  describe('Full Booking Flow', () => {
    it('should open modal, fill form, submit, and see success', fakeAsync(() => {
        // 1. Open booking modal
        const bookButtonNav = fixture.debugElement.query(By.css('app-navbar button.btn-primary'));
        bookButtonNav.nativeElement.click();
        fixture.detectChanges();
        
        let modal = fixture.debugElement.query(By.css('app-booking-modal'));
        expect(modal).toBeTruthy();
        
        // 2. Fill the form
        const bookingFormComponentEl = modal.query(By.css('app-booking-form'));
        const bookingFormComponent = bookingFormComponentEl.componentInstance;
        
        const bookingForm = bookingFormComponent.bookingForm;
        bookingForm.get('date')?.setValue('2024-12-31');
        bookingForm.get('time')?.setValue('23:55');
        
        const transferTypeSelect = bookingFormComponentEl.query(By.css('#transferType')).nativeElement;
        transferTypeSelect.value = 'airport';
        transferTypeSelect.dispatchEvent(new Event('change'));
        fixture.detectChanges();
        tick();
        fixture.detectChanges();
        
        const routeSelect = bookingFormComponentEl.query(By.css('#route')).nativeElement;
        routeSelect.value = 'BA-VIE';
        routeSelect.dispatchEvent(new Event('change'));
        
        const emailInput = bookingFormComponentEl.query(By.css('#email')).nativeElement;
        emailInput.value = 'test@example.com';
        emailInput.dispatchEvent(new Event('input'));

        const phoneInput = bookingFormComponentEl.query(By.css('#phone')).nativeElement;
        phoneInput.value = '+421999888777';
        phoneInput.dispatchEvent(new Event('input'));
        
        fixture.detectChanges();
        expect(bookingForm.valid).toBeTruthy();
        
        // 3. Submit
        const submitButton = bookingFormComponentEl.query(By.css('button[type="submit"]')).nativeElement;
        submitButton.click();
        fixture.detectChanges();

        expect(bookingFormComponent.isLoading()).toBe(true);
        tick(1500); // Wait for simulated API call
        fixture.detectChanges();
        
        // 4. Assert success
        expect(bookingFormComponent.isLoading()).toBe(false);
        const toast = fixture.debugElement.query(By.css('app-toast .toast-item.border-green-500'));
        expect(toast).toBeTruthy();
        expect(toast.nativeElement.textContent).toContain('Rezervácia bola úspešne odoslaná');
        
        expect(bookingForm.get('date')?.value).toBeNull();
    }));
  });
  
  describe('Language Switching', () => {
    it('should change hero title when language is switched', () => {
      const heroTitleEl = (): HTMLElement => fixture.debugElement.query(By.css('#home h1')).nativeElement;

      expect(heroTitleEl().textContent).toContain('Bratislava. Viedeň.');
      
      const langSwitcher = fixture.debugElement.query(By.css('app-navbar div.relative button'));
      langSwitcher.nativeElement.click();
      fixture.detectChanges();

      const langButtons = fixture.debugElement.queryAll(By.css('div[class*="absolute"] button'));
      const englishButtonElement = langButtons.find(b => b.nativeElement.textContent.includes('English'))?.nativeElement;
      expect(englishButtonElement).toBeTruthy();
      englishButtonElement.click();
      fixture.detectChanges();

      expect(heroTitleEl().textContent).toContain('Bratislava. Vienna.');
    });
  });

  describe('FAQ Interaction', () => {
    it('should open and close an FAQ item on click', () => {
      const faqSection = fixture.debugElement.query(By.css('app-faq'));
      const faqItems = faqSection.queryAll(By.css('.space-y-4 > div'));
      const firstFaqButton = faqItems[0].query(By.css('button')).nativeElement;
      
      let answerDiv = faqItems[0].query(By.css('.faq-answer'));
      expect(answerDiv.classes['is-open']).toBeFalsy();

      firstFaqButton.click();
      fixture.detectChanges();

      answerDiv = faqItems[0].query(By.css('.faq-answer'));
      expect(answerDiv.classes['is-open']).toBeTruthy();

      firstFaqButton.click();
      fixture.detectChanges();
      
      answerDiv = faqItems[0].query(By.css('.faq-answer'));
      expect(answerDiv.classes['is-open']).toBeFalsy();
    });
  });
});