import { Injectable, signal } from '@angular/core';

export interface Notification {
  id: number;
  message: string;
  type: 'success' | 'error';
}

@Injectable({ providedIn: 'root' })
export class NotificationService {
  readonly notifications = signal<Notification[]>([]);
  private idCounter = 0;

  show(message: string, type: 'success' | 'error' = 'success', duration: number = 5000): void {
    const id = this.idCounter++;
    this.notifications.update(current => [...current, { id, message, type }]);

    setTimeout(() => {
      this.remove(id);
    }, duration);
  }

  remove(id: number): void {
    this.notifications.update(current => current.filter(n => n.id !== id));
  }
}
