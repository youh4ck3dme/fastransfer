import { Component, ChangeDetectionStrategy, signal, inject, OnInit, OnDestroy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { SeoService } from '../../seo.service';
import { TranslationService } from '../../services/translation.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

interface FaqItem {
  question: string;
  answer: string;
  isOpen: boolean;
}

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [CommonModule, AnimateOnScrollDirective, TranslatePipe],
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FaqComponent implements OnInit, OnDestroy {
  private readonly seoService = inject(SeoService);
  private readonly translationService = inject(TranslationService);

  private activeIndex = signal<number | null>(null);
  
  // Create a computed signal that returns the translated FAQ items
  readonly faqItems = computed(() => {
    const t = (key: string) => this.translationService.translate(key);
    return [
      { question: t('faq.q1'), answer: t('faq.a1'), isOpen: this.activeIndex() === 0 },
      { question: t('faq.q2'), answer: t('faq.a2'), isOpen: this.activeIndex() === 1 },
      { question: t('faq.q3'), answer: t('faq.a3'), isOpen: this.activeIndex() === 2 },
      { question: t('faq.q4'), answer: t('faq.a4'), isOpen: this.activeIndex() === 3 },
    ];
  });
  
  ngOnInit(): void {
    // Note: SEO schema might need to be updated dynamically if language changes are frequent
    this.seoService.setFaqSchema(this.faqItems());
  }

  ngOnDestroy(): void {
    this.seoService.removeFaqSchema();
  }

  toggleItem(index: number): void {
    this.activeIndex.update(current => (current === index ? null : index));
  }
}
