
import { bootstrapApplication } from '@angular/platform-browser';
import { provideZonelessChangeDetection } from '@angular/core';
import { AppComponent } from './src/app.component';
import { provideHttpClient } from '@angular/common/http';
import { provideServiceWorker } from '@angular/service-worker';
import { fromEvent } from 'rxjs';


bootstrapApplication(AppComponent, {
  providers: [
    provideZonelessChangeDetection(),
    provideHttpClient(),
    provideServiceWorker(`${location.origin}/ngsw-worker.js`, {
        enabled: true, // In real-world app, this would be !isDevMode()
        // FIX: Explicitly wait for the window 'load' event to prevent InvalidStateError.
        registrationStrategy: () => fromEvent(window, 'load')
    })
  ],
}).catch(err => console.error(err));

// AI Studio always uses an `index.tsx` file for all project types.