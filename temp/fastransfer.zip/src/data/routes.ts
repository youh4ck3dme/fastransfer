// Centralized interface for type safety
export interface RouteOption {
  value: string;
  label: string;
  price?: string;
  highlight?: boolean;
}

// Centralized city routes data
export const cityRoutes: RouteOption[] = [
  { value: 'BA-Centrum', label: 'BA > Centrum', price: '20 €' },
  { value: 'BA-Trnava', label: 'BA > Trnava', price: '60 €' },
  { value: 'BA-DStreda', label: 'BA > D. Streda', price: '60 €' },
  { value: 'BA-Nitra', label: 'BA > Nitra', price: '100 €' },
  { value: 'BA-Trencin', label: 'BA > Trenčín', price: '135 €' },
  { value: 'BA-Brno', label: 'BA > Brno', price: '145 €' },
  { value: 'BA-Budapest', label: 'BA > Budapešť', price: '220 €' },
  { value: 'BA-Praha', label: 'BA > Praha', price: '320 €' },
  { value: 'BA-Kosice', label: 'BA > Košice', price: '400 €' },
];

// Centralized airport routes data
export const airportRoutes: RouteOption[] = [
  { value: 'BA-BTS', label: 'BA > Letisko M.R.Š (BTS)', price: '30 €' },
  { value: 'BA-VIE', label: 'BA > Letisko Viedeň (VIE)', price: '64 €', highlight: true },
  { value: 'BA-BUD', label: 'BA > Letisko Budapešť (BUD)', price: '240 €' },
  { value: 'BA-PRG', label: 'BA > Letisko Praha (PRG)', price: '340 €' },
  { value: 'BA-KSC', label: 'BA > Letisko Košice (KSC)', price: '390 €' },
  { value: 'BA-KRK', label: 'BA > Letisko Krakov (KRK)', price: '400 €' },
];