import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { PwaInstallService } from '../../pwa-install.service';
import { NgOptimizedImage } from '@angular/common';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-install-prompt',
  templateUrl: './install-prompt.component.html',
  standalone: true,
  imports: [NgOptimizedImage, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InstallPromptComponent {
  private readonly pwaInstallService = inject(PwaInstallService);
  readonly canInstall = this.pwaInstallService.canInstall;
  readonly isVisible = signal(true);

  installApp(): void {
    this.pwaInstallService.promptToInstall();
  }

  dismiss(): void {
    this.isVisible.set(false);
  }
}
