import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingFormComponent } from '../booking-form/booking-form.component';
import { TrapFocusDirective } from '../../directives/trap-focus.directive';
import { BookingDetails } from '../../gemini.service';

@Component({
  selector: 'app-booking-modal',
  standalone: true,
  imports: [CommonModule, BookingFormComponent, TrapFocusDirective],
  templateUrl: './booking-modal.component.html',
  styleUrls: ['./booking-modal.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BookingModalComponent {
  isOpen = input.required<boolean>();
  initialDetails = input<Partial<BookingDetails> | null>(null);
  close = output<void>();

  onClose(): void {
    this.close.emit();
  }
}