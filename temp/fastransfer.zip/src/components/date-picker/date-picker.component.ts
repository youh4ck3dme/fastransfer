import { Component, ChangeDetectionStrategy, forwardRef, signal, HostListener, ElementRef, inject, input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-date-picker',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DatePickerComponent),
      multi: true
    }
  ]
})
export class DatePickerComponent implements ControlValueAccessor {
  private readonly elementRef = inject(ElementRef);
  
  // CVA boilerplate
  onChange: (value: string | null) => void = () => {};
  onTouched: () => void = () => {};
  
  readonly isInvalid = input(false);
  readonly variant = input<'default' | 'hero'>('default');
  
  readonly value = signal<string | null>(null); // YYYY-MM-DD
  readonly isDisabled = signal(false);
  readonly isOpen = signal(false);

  // Calendar state
  readonly currentDate = signal(new Date());
  readonly calendarDays = signal<Date[][]>([]);

  constructor() {
    this.generateCalendar(this.currentDate().getFullYear(), this.currentDate().getMonth());
  }
  
  host = {
    '(document:click)': (event: MouseEvent) => {
      if (!this.elementRef.nativeElement.contains(event.target)) {
        this.isOpen.set(false);
      }
    }
  }

  writeValue(obj: string | null): void {
    if (obj && /^\d{4}-\d{2}-\d{2}$/.test(obj)) {
      this.value.set(obj);
      const parts = obj.split('-');
      // new Date(year, monthIndex, day) - avoids timezone issues
      const date = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      this.currentDate.set(date);
      this.generateCalendar(date.getFullYear(), date.getMonth());
    } else {
        this.value.set(null); 
        const today = new Date();
        this.currentDate.set(today);
        this.generateCalendar(today.getFullYear(), today.getMonth());
    }
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
  setDisabledState?(isDisabled: boolean): void { this.isDisabled.set(isDisabled); }

  togglePicker(): void {
    if (!this.isDisabled()) {
      this.isOpen.update(v => !v);
      this.onTouched();
    }
  }

  selectDate(day: Date): void {
    if (this.isPastDate(day)) return;
    const selectedValue = this.formatDate(day);
    this.value.set(selectedValue);
    this.onChange(selectedValue);
    this.isOpen.set(false);
  }

  prevMonth(): void {
    this.currentDate.update(d => {
      d.setMonth(d.getMonth() - 1);
      return new Date(d);
    });
    this.generateCalendar(this.currentDate().getFullYear(), this.currentDate().getMonth());
  }

  nextMonth(): void {
    this.currentDate.update(d => {
      d.setMonth(d.getMonth() + 1);
      return new Date(d);
    });
    this.generateCalendar(this.currentDate().getFullYear(), this.currentDate().getMonth());
  }

  private generateCalendar(year: number, month: number): void {
    const weeks: Date[][] = [];
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    let currentDate = new Date(firstDayOfMonth);
    // Go back to the first day of the week (Monday)
    const dayOfWeek = currentDate.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
    const offset = (dayOfWeek === 0) ? 6 : dayOfWeek - 1; // 0=Mon, 1=Tue, ..., 6=Sun
    currentDate.setDate(currentDate.getDate() - offset);

    for (let i = 0; i < 6; i++) {
        const week: Date[] = [];
        for (let j = 0; j < 7; j++) {
            week.push(new Date(currentDate));
            currentDate.setDate(currentDate.getDate() + 1);
        }
        weeks.push(week);
        // Optimization: if the first day of the last week is after the end of the month, stop.
        if (weeks.length > 4 && lastDayOfMonth < weeks[weeks.length-1][0]) {
            break;
        }
    }
    this.calendarDays.set(weeks);
  }

  private formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  isToday(date: Date): boolean {
    const today = new Date();
    return this.formatDate(date) === this.formatDate(today);
  }
  
  isSelected(date: Date): boolean {
    return this.value() === this.formatDate(date);
  }

  isCurrentMonth(date: Date): boolean {
    return date.getMonth() === this.currentDate().getMonth();
  }

  isPastDate(date: Date): boolean {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  }
}