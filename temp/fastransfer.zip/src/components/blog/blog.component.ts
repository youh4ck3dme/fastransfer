import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { blogPosts, BlogPost } from '../../data/blog-posts';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { BlogPostComponent } from '../blog-post/blog-post.component';

@Component({
  selector: 'app-blog',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, AnimateOnScrollDirective, TranslatePipe, BlogPostComponent],
  templateUrl: './blog.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BlogComponent {
  readonly posts = signal<BlogPost[]>(blogPosts);
  readonly selectedPost = signal<BlogPost | null>(null);

  selectPost(post: BlogPost): void {
    this.selectedPost.set(post);
    window.scrollTo(0, 0);
  }

  showPostList(): void {
    this.selectedPost.set(null);
  }
}
