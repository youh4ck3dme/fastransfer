import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { NotificationService } from '../../notification.service';
import { SafePipe } from '../../pipes/safe.pipe';
import { NetworkStatusService } from '../../network-status.service';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-contact-info',
  standalone: true,
  imports: [AnimateOnScrollDirective, SafePipe, ReactiveFormsModule, TranslatePipe],
  templateUrl: './contact-info.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ContactInfoComponent {
  private readonly notificationService = inject(NotificationService);
  private readonly fb = inject(FormBuilder);
  private readonly networkStatusService = inject(NetworkStatusService);
  private readonly translationService = inject(TranslationService);

  readonly isOnline = this.networkStatusService.isOnline;
  readonly isLoading = signal(false);
  readonly copyButtonTextKey = signal('contact.copy');

  readonly contactForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    subject: ['', Validators.required],
    message: ['', [Validators.required, Validators.minLength(10)]],
  });

  readonly contact = {
    phones: [
      { display: '+421 902 609 940', link: 'tel:+421902609940' },
      { display: '+421 911 923 573', link: 'tel:+421911923573' },
    ],
    email: 'info@fastransfer.sk',
    socials: {
      instagram: 'https://www.instagram.com/fastransfer/',
      facebook: 'https://www.facebook.com/fastransfer',
    },
    invoicing: {
      name: 'GAR&DIER, s. r. o.',
      address: 'Doležalova 3424/15C, 821 04 Bratislava – Ružinov',
      ico: '53 228 243',
    },
    mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2661.168750611894!2d17.1682638156497!3d48.16335197922579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476c8edc25c34591%3A0x6a9359e13f413446!2sDole%C5%BEalova%203424%2F15c%2C%20821%2004%20Bratislava!5e0!3m2!1sen!2ssk!4v1620986968988!5m2!1sen!2ssk'
  };

  copyToClipboard(text: string): void {
    navigator.clipboard.writeText(text).then(() => {
      this.notificationService.show(this.translationService.translate('notification.email.copied'), 'success');
      this.copyButtonTextKey.set('contact.copied');
      setTimeout(() => this.copyButtonTextKey.set('contact.copy'), 2000);
    }, (err) => {
      console.error('Could not copy text: ', err);
      this.notificationService.show(this.translationService.translate('notification.email.copyFailed'), 'error');
    });
  }

  isFieldInvalid(fieldName: string): boolean {
    const control = this.contactForm.get(fieldName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  async onFormSubmit(): Promise<void> {
    if (this.contactForm.invalid) {
      this.contactForm.markAllAsTouched();
      this.notificationService.show(this.translationService.translate('notification.contact.form.error'), 'error');
      return;
    }
    
    if (!this.isOnline()) {
        this.notificationService.show(this.translationService.translate('notification.form.offline'), 'error');
        return;
    }

    this.isLoading.set(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    console.log('Contact form submitted:', this.contactForm.value);
    this.notificationService.show(this.translationService.translate('notification.contact.form.success'), 'success');
    this.contactForm.reset();
    
    // Explicitly mark controls as untouched and pristine
    Object.keys(this.contactForm.controls).forEach(key => {
        this.contactForm.get(key)?.markAsPristine();
        this.contactForm.get(key)?.markAsUntouched();
    });
    
    this.isLoading.set(false);
  }
}