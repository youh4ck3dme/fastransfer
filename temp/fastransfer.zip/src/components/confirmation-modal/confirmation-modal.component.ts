import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TrapFocusDirective } from '../../directives/trap-focus.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-confirmation-modal',
  standalone: true,
  imports: [CommonModule, TrapFocusDirective, TranslatePipe],
  templateUrl: './confirmation-modal.component.html',
  styleUrls: ['./confirmation-modal.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConfirmationModalComponent {
  isOpen = input.required<boolean>();
  bookingData = input<any | null>(null);
  
  confirm = output<void>();
  close = output<void>();

  onConfirm(): void {
    this.confirm.emit();
  }

  onClose(): void {
    this.close.emit();
  }
}