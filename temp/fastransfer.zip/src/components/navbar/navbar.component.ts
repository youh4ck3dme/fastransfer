import { Component, ChangeDetectionStrategy, signal, output, inject, input, ElementRef } from '@angular/core';
import { TranslationService, Language } from '../../services/translation.service';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { SafePipe } from '../../pipes/safe.pipe';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  standalone: true,
  imports: [TranslatePipe, SafePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:click)': 'onDocumentClick($event)',
  }
})
export class NavbarComponent {
  private readonly translationService = inject(TranslationService);
  private readonly elementRef = inject(ElementRef);

  isMobileMenuOpen = signal(false);
  isLangMenuOpen = signal(false);
  openBookingModal = output<void>();
  themeToggle = output<void>();
  homeClicked = output<void>();
  blogClicked = output<void>();

  currentTheme = input.required<'light' | 'dark'>();
  currentLang = this.translationService.currentLang;
  languages = this.translationService.languages;

  onDocumentClick(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.isLangMenuOpen.set(false);
    }
  }

  toggleMobileMenu(): void {
    this.isMobileMenuOpen.update(value => !value);
    this.isLangMenuOpen.set(false);
  }

  toggleLangMenu(): void {
    this.isLangMenuOpen.update(value => !value);
  }

  changeLanguage(lang: Language): void {
    this.translationService.changeLanguage(lang);
    this.isLangMenuOpen.set(false);
  }

  onThemeToggleClick(): void {
    this.themeToggle.emit();
  }

  onHomeClick(): void {
    this.homeClicked.emit();
    this.isMobileMenuOpen.set(false);
  }
  
  onBlogClick(): void {
    this.blogClicked.emit();
    this.isMobileMenuOpen.set(false);
  }
}
