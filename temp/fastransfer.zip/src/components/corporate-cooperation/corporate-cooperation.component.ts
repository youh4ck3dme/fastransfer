import { Component, ChangeDetectionStrategy } from '@angular/core';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-corporate-cooperation',
  standalone: true,
  imports: [AnimateOnScrollDirective, TranslatePipe],
  templateUrl: './corporate-cooperation.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CorporateCooperationComponent {}
