import { Component, ChangeDetectionStrategy, output, signal, inject, OnInit } from '@angular/core';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { NgOptimizedImage } from '@angular/common';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { SeoService } from '../../seo.service';

export interface Vehicle {
  name: string;
  year: number;
  class: string; // Translation key
  imageUrl: string;
  transmission: string; // Translation key
  power: string;
  passengers: string;
}

@Component({
  selector: 'app-fleet',
  standalone: true,
  imports: [AnimateOnScrollDirective, NgOptimizedImage, TranslatePipe],
  templateUrl: './fleet.component.html',
  styleUrls: ['./fleet.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FleetComponent implements OnInit {
  private readonly seoService = inject(SeoService);
  openBookingModal = output<void>();

  readonly vehicles = signal<Vehicle[]>([
    {
      name: 'Mercedes-Benz S-Class',
      year: 2022,
      class: 'fleet.class.premium',
      imageUrl: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=600&h=400&fit=crop',
      transmission: 'fleet.transmission.auto',
      power: '320 kW',
      passengers: '1-3'
    },
    {
      name: 'Mercedes-Benz E-Class',
      year: 2021,
      class: 'fleet.class.premium',
      imageUrl: 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=600&h=400&fit=crop',
      transmission: 'fleet.transmission.auto',
      power: '190 kW',
      passengers: '1-3'
    },
    {
      name: 'Mercedes-Benz V-Class',
      year: 2022,
      class: 'fleet.class.premium',
      imageUrl: 'https://images.unsplash.com/photo-1631293343169-5989ebd3153b?w=600&h=400&fit=crop',
      transmission: 'fleet.transmission.auto',
      power: '176 kW',
      passengers: '1-7'
    },
    {
      name: 'Mercedes-Benz C-Class',
      year: 2020,
      class: 'fleet.class.standard',
      imageUrl: 'https://images.unsplash.com/photo-1555529771-788850a3c2b2?w=600&h=400&fit=crop',
      transmission: 'fleet.transmission.auto',
      power: '150 kW',
      passengers: '1-3'
    }
  ]);

  ngOnInit(): void {
    this.addVehicleSchemas();
  }

  private addVehicleSchemas(): void {
    const schemas = this.vehicles().map(vehicle => ({
      "@context": "https://schema.org",
      "@type": "Vehicle",
      "name": `${vehicle.name} (${vehicle.year})`,
      "vehicleModelDate": vehicle.year,
      "brand": vehicle.name.split(' ')[0],
      "image": vehicle.imageUrl,
      "seatingCapacity": vehicle.passengers.split('-')[1] || vehicle.passengers,
      "vehicleTransmission": "Automatic" // Assuming all are auto based on data
    }));
    this.seoService.setCollectionSchema('vehicles', schemas);
  }
}