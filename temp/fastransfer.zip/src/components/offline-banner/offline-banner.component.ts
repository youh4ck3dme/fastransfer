import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { NetworkStatusService } from '../../network-status.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-offline-banner',
  templateUrl: './offline-banner.component.html',
  standalone: true,
  imports: [TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OfflineBannerComponent {
  private readonly networkStatusService = inject(NetworkStatusService);
  readonly isOnline = this.networkStatusService.isOnline;
}
