import { describe, it, expect, beforeEach } from '@jest/globals';
import { TestBed } from '@angular/core/testing';
import { TranslationService, Language } from './translation.service';

describe('TranslationService', () => {
  let service: TranslationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TranslationService]
    });
    service = TestBed.inject(TranslationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initialize with "sk" as the default language', () => {
    expect(service.currentLang()).toBe('sk');
  });

  it('should change language when changeLanguage is called', () => {
    service.changeLanguage('en');
    expect(service.currentLang()).toBe('en');

    service.changeLanguage('de');
    expect(service.currentLang()).toBe('de');
  });

  it('should translate a key correctly for the current language', () => {
    service.changeLanguage('sk');
    expect(service.translate('nav.about')).toBe('O Nás');

    service.changeLanguage('en');
    expect(service.translate('nav.about')).toBe('About Us');
    
    service.changeLanguage('de');
    expect(service.translate('nav.about')).toBe('Über Uns');
  });

  it('should return the key if translation is not found', () => {
    const nonExistentKey = 'this.key.does.not.exist';
    expect(service.translate(nonExistentKey)).toBe(nonExistentKey);
  });

  it('should correctly interpolate parameters into the translated string', () => {
    service.changeLanguage('en');
    const interpolated = service.translate('test.interpolation', { param: 'VALUE' });
    expect(interpolated).toBe('Test with parameter VALUE.');

    service.changeLanguage('sk');
    const interpolatedSk = service.translate('test.interpolation', { param: 'HODNOTA' });
    expect(interpolatedSk).toBe('Test s parametrom HODNOTA.');
    
    service.changeLanguage('de');
    const interpolatedDe = service.translate('test.interpolation', { param: 'WERT' });
    expect(interpolatedDe).toBe('Test mit Parameter WERT.');
  });
});
