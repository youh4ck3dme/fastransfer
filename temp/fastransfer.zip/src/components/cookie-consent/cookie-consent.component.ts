import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CookieService } from '../../cookie.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-cookie-consent',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './cookie-consent.component.html',
  styleUrls: ['./cookie-consent.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CookieConsentComponent {
  private readonly cookieService = inject(CookieService);
  
  readonly showBanner = this.cookieService.showBanner;
  readonly openPrivacyPolicy = output<void>();

  accept(): void {
    this.cookieService.accept();
  }

  decline(): void {
    this.cookieService.decline();
  }
}
