import { Injectable, inject, Renderer2, RendererFactory2 } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class SeoService {
  // FIX: Explicitly type `document` to resolve TypeScript inference issues.
  private readonly document: Document = inject(DOCUMENT);
  private readonly renderer: Renderer2;
  private schemaScripts: Map<string, HTMLElement[]> = new Map();

  constructor(rendererFactory: RendererFactory2) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  private createSchemaScript(schema: object): HTMLScriptElement {
    const script = this.renderer.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schema, null, 2);
    return script;
  }
  
  private setSchema(id: string, schema: object): void {
    this.removeSchema(id);

    const script = this.createSchemaScript(schema);
    this.renderer.setProperty(script, 'id', `schema-${id}`);
    this.renderer.appendChild(this.document.head, script);
    this.schemaScripts.set(id, [script]);
  }

  setCollectionSchema(id: string, schemas: object[]): void {
    this.removeSchema(id);
    
    const scripts: HTMLElement[] = [];
    schemas.forEach((schema, index) => {
        const script = this.createSchemaScript(schema);
        this.renderer.setProperty(script, 'id', `schema-${id}-${index}`);
        this.renderer.appendChild(this.document.head, script);
        scripts.push(script);
    });
    
    this.schemaScripts.set(id, scripts);
  }
  
  setAggregateRatingSchema(itemName: string, rating: object): void {
      const schema = {
          "@context": "https://schema.org",
          "@type": "TaxiService", // Can be adapted based on context
          "name": itemName,
          "aggregateRating": rating
      };
      this.setSchema('aggregate-rating', schema);
  }

  private removeSchema(id: string): void {
    const scripts = this.schemaScripts.get(id);
    if (scripts) {
      scripts.forEach(script => {
        if (script.parentNode) {
           this.renderer.removeChild(this.document.head, script);
        }
      });
      this.schemaScripts.delete(id);
    }
  }

  setFaqSchema(faqItems: { question: string; answer: string }[]): void {
    const schema = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqItems.map(item => ({
        "@type": "Question",
        "name": item.question,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": item.answer
        }
      }))
    };
    this.setSchema('faq', schema);
  }

  removeFaqSchema(): void {
    this.removeSchema('faq');
  }
}