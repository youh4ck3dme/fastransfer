import { Injectable } from '@angular/core';
import { GoogleGenAI, GenerateContentResponse, Type } from '@google/genai';
import { cityRoutes, airportRoutes } from './data/routes';

export interface BookingDetails {
  date: string | null; // YYYY-MM-DD
  time: string | null; // HH:MM
  transferType: 'city' | 'airport' | null;
  routeValue: string | null;
  passengers: number | null;
  destination?: string;
}

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | null = null;
  
  // Dynamically generate prompt strings from the single source of truth
  private readonly cityRoutesForPrompt = cityRoutes
    .map(route => `- ${route.value}: ${route.label}`)
    .join('\n');
  private readonly airportRoutesForPrompt = airportRoutes
    .map(route => `- ${route.value}: ${route.label}`)
    .join('\n');

  constructor() {
    try {
      if (process.env.API_KEY) {
        this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      } else {
        console.error('API_KEY environment variable not found.');
      }
    } catch (e) {
        console.error('Error initializing GoogleGenAI:', e);
    }
  }
  
  isAvailable(): boolean {
    return this.ai !== null;
  }

  async getBookingDetailsFromText(prompt: string): Promise<BookingDetails> {
    if (!this.ai) {
        throw new Error('Gemini AI client is not initialized. Check API_KEY.');
    }

    const today = new Date().toISOString().split('T')[0];

    const systemInstruction = `
        You are an intelligent assistant for a VIP transport booking form.
        Your task is to parse the user's request and extract booking details into a structured JSON object.
        Today's date is ${today}. If the user mentions "zajtra" (tomorrow), calculate the correct date. If they mention a day of the week, figure out the date for the upcoming specified day.
        The user is located in Bratislava (BA), so all routes start from there.
        Infer the 'transferType' based on the destination. If it's an airport, set 'transferType' to 'airport'. Otherwise, set it to 'city'.
        Match the destination to the closest 'routeValue' from the provided lists. You MUST return one of the exact route values.
        Also, extract the number of passengers.

        Available route values for 'city' transferType:
        ${this.cityRoutesForPrompt}

        Available route values for 'airport' transferType:
        ${this.airportRoutesForPrompt}
        
        If you cannot determine a required value, set it to null.
    `;
    
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            date: { type: Type.STRING, description: 'The date of the ride in YYYY-MM-DD format.' },
            time: { type: Type.STRING, description: 'The time of the ride in HH:MM (24-hour) format.' },
            transferType: { type: Type.STRING, description: 'The type of transfer, either "city" or "airport".' },
            routeValue: { type: Type.STRING, description: 'The unique identifier for the route, e.g., "BA-VIE". Must be one of the provided values.' },
            passengers: { type: Type.INTEGER, description: 'The number of passengers.' },
        }
    };

    try {
      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema,
        }
      });

      const jsonText = response.text.trim();
      return JSON.parse(jsonText) as BookingDetails;
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      throw new Error('Failed to get booking details from AI. Please try again.');
    }
  }
}