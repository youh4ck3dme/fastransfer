import { Component, ChangeDetectionStrategy, signal, inject, OnInit, AfterViewInit, ElementRef, Renderer2, PLATFORM_ID } from '@angular/core';
import { CommonModule, NgOptimizedImage, isPlatformBrowser } from '@angular/common';
import { AnimateOnScrollDirective } from '../../directives/animate-on-scroll.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { SeoService } from '../../seo.service';

interface Testimonial {
  name: string;
  rating: number; // out of 5
  text: string;
  datePublished?: string; // YYYY-MM-DD for schema
}

interface Partner {
  name: string;
  logoUrl: string;
}

@Component({
  selector: 'app-testimonials',
  standalone: true,
  imports: [CommonModule, AnimateOnScrollDirective, NgOptimizedImage, TranslatePipe],
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TestimonialsComponent implements OnInit, AfterViewInit {
  private readonly seoService = inject(SeoService);
  private readonly elementRef = inject(ElementRef);
  private readonly renderer = inject(Renderer2);
  private readonly platformId = inject(PLATFORM_ID);

  readonly testimonials = signal<Testimonial[]>([
    {
      name: 'Martin K.',
      rating: 5,
      text: 'Absolútne profesionálny prístup. Vodič bol presný, auto čisté a cesta na letisko Viedeň bola maximálne komfortná. Určite využijem znova.',
      datePublished: '2024-05-10',
    },
    {
      name: 'Lucia Vargová',
      rating: 5,
      text: 'Využili sme služby FasTransfer pre našich zahraničných partnerov. Všetko prebehlo perfektne, komunikácia bola na jednotku. Veľká spokojnosť.',
      datePublished: '2024-04-22',
    },
    {
      name: 'Peter Novotný',
      rating: 5,
      text: 'Spoľahlivý odvoz na firemnú akciu. Vodič bol veľmi ústretový a flexibilný. Odporúčam všetkým, ktorí hľadajú kvalitu.',
      datePublished: '2024-03-15',
    },
    {
      name: 'Erika J.',
      rating: 4,
      text: 'Príjemná jazda, moderné auto s WiFi. Jediná drobnosť bola, že som si zabudla objednať detskú sedačku, ale vodič to rýchlo vyriešil.',
      datePublished: '2024-02-18',
    },
    {
      name: 'Ján F.',
      rating: 5,
      text: 'Skvelá služba. Jednoduchá online rezervácia a platba kartou priamo v aute. Vodič bol milý a profesionálny. Cesta bola rýchla a bezpečná.',
      datePublished: '2024-06-01',
    },
  ]);

  readonly partners = signal<Partner[]>([
    { name: 'ESET', logoUrl: 'https://logo.clearbit.com/eset.com' },
    { name: 'Slovenská sporiteľňa', logoUrl: 'https://logo.clearbit.com/slsp.sk' },
    { name: 'Accenture', logoUrl: 'https://logo.clearbit.com/accenture.com' },
    { name: 'O2 Slovakia', logoUrl: 'https://logo.clearbit.com/o2.sk' },
    { name: 'KPMG', logoUrl: 'https://logo.clearbit.com/kpmg.com' },
  ]);

  ngOnInit(): void {
    this.addTestimonialsSchema();
  }
  
  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.duplicateTestimonialsForAnimation();
    }
  }

  private duplicateTestimonialsForAnimation(): void {
    const scrollerInner = this.elementRef.nativeElement.querySelector('.scroller__inner');
    if (scrollerInner) {
      const testimonials = Array.from(scrollerInner.children);
      testimonials.forEach(testimonial => {
        // FIX: Cast the iterated element to `Element` as TypeScript was inferring it as `unknown`, preventing access to `cloneNode`.
        const duplicatedTestimonial = (testimonial as Element).cloneNode(true) as HTMLElement;
        this.renderer.setAttribute(duplicatedTestimonial, 'aria-hidden', 'true');
        this.renderer.appendChild(scrollerInner, duplicatedTestimonial);
      });
    }
  }

  private addTestimonialsSchema(): void {
    const reviews = this.testimonials().map(testimonial => ({
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": testimonial.name
      },
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": testimonial.rating.toString(),
        "bestRating": "5"
      },
      "reviewBody": testimonial.text,
      "datePublished": testimonial.datePublished || new Date().toISOString().split('T')[0]
    }));
    
    const averageRating = this.testimonials().reduce((acc, t) => acc + t.rating, 0) / this.testimonials().length;

    const aggregateRating = {
      "@type": "AggregateRating",
      "ratingValue": averageRating.toFixed(1),
      "reviewCount": this.testimonials().length
    };
    
    this.seoService.setAggregateRatingSchema('FasTransfer.sk', aggregateRating);
    this.seoService.setCollectionSchema('reviews', reviews);
  }
}