import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { BlogPost } from '../../data/blog-posts';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { SafePipe } from '../../pipes/safe.pipe';

@Component({
  selector: 'app-blog-post',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, TranslatePipe, SafePipe],
  templateUrl: './blog-post.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BlogPostComponent {
  post = input.required<BlogPost>();
  back = output<void>();
}
