import { Component, ChangeDetectionStrategy, forwardRef, signal, input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-time-picker',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './time-picker.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TimePickerComponent),
      multi: true
    }
  ]
})
export class TimePickerComponent implements ControlValueAccessor {
  onChange: (value: string | null) => void = () => {};
  onTouched: () => void = () => {};

  readonly selectedHour = signal<string | null>(null);
  readonly selectedMinute = signal<string | null>(null);
  readonly isDisabled = signal(false);
  readonly isInvalid = input(false);

  readonly hours = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
  readonly minutes = Array.from({ length: 12 }, (_, i) => (i * 5).toString().padStart(2, '0'));

  writeValue(value: string | null): void {
    if (value && value.includes(':')) {
      const [h, m] = value.split(':');
      this.selectedHour.set(h);
      this.selectedMinute.set(m);
    } else {
      this.selectedHour.set(null);
      this.selectedMinute.set(null);
    }
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
  setDisabledState?(isDisabled: boolean): void { this.isDisabled.set(isDisabled); }

  onHourChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.selectedHour.set(value || null);
    this.updateValue();
  }
  
  onMinuteChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.selectedMinute.set(value || null);
    this.updateValue();
  }
  
  private updateValue(): void {
    this.onTouched();
    const h = this.selectedHour();
    const m = this.selectedMinute();
    if (h && m) {
      this.onChange(`${h}:${m}`);
    } else {
      this.onChange(null);
    }
  }
}