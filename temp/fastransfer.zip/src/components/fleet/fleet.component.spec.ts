import { describe, it, expect, beforeEach, jest } from '@jest/globals';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FleetComponent } from './fleet.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';

describe('FleetComponent', () => {
  let component: FleetComponent;
  let fixture: ComponentFixture<FleetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FleetComponent, NoopAnimationsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(FleetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with 4 vehicles', () => {
    expect(component.vehicles().length).toBe(4);
  });

  it('should render 4 vehicle flip cards', () => {
    const cardElements = fixture.debugElement.queryAll(By.css('.flip-card-container'));
    expect(cardElements.length).toBe(4);
  });

  it('should display vehicle name and year on the front of the card', () => {
    const firstVehicle = component.vehicles()[0];
    const firstCardFront = fixture.debugElement.query(By.css('.flip-card-front'));
    
    const nameElement = firstCardFront.query(By.css('h3')).nativeElement;
    const yearElement = firstCardFront.query(By.css('p')).nativeElement;

    expect(nameElement.textContent).toContain(firstVehicle.name);
    expect(yearElement.textContent).toContain(firstVehicle.year.toString());
  });

  it('should display vehicle details on the back of the card', () => {
    const firstVehicle = component.vehicles()[0];
    const firstCardBack = fixture.debugElement.query(By.css('.flip-card-back'));
    const detailsText = firstCardBack.nativeElement.textContent;

    expect(detailsText).toContain(firstVehicle.name);
    // Note: In a real test, we would use a TranslatePipe mock or the actual pipe.
    // Here, we check for the key, which is sufficient for this setup.
    expect(detailsText).toContain('fleet.transmission');
    expect(detailsText).toContain(firstVehicle.power);
    expect(detailsText).toContain('fleet.passengers');
    expect(detailsText).toContain(firstVehicle.passengers);
  });

  it('should emit openBookingModal event when "Rezervovať Teraz" button is clicked', () => {
    const openBookingModalSpy = jest.spyOn(component.openBookingModal, 'emit');

    const bookingButton = fixture.debugElement.query(By.css('.flip-card-back button'));
    bookingButton.triggerEventHandler('click', null);

    expect(openBookingModalSpy).toHaveBeenCalled();
  });
});
