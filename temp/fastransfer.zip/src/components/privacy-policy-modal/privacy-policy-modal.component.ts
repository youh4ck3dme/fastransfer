import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TrapFocusDirective } from '../../directives/trap-focus.directive';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { SafePipe } from '../../pipes/safe.pipe';

@Component({
  selector: 'app-privacy-policy-modal',
  standalone: true,
  imports: [CommonModule, TrapFocusDirective, TranslatePipe, SafePipe],
  templateUrl: './privacy-policy-modal.component.html',
  styleUrls: ['./privacy-policy-modal.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PrivacyPolicyModalComponent {
  isOpen = input.required<boolean>();
  close = output<void>();

  onClose(): void {
    this.close.emit();
  }
}
