// FIX: Import test functions from @jest/globals to resolve undefined test runner function errors.
import { describe, it, expect, beforeEach, jest } from '@jest/globals';

import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { BookingFormComponent } from './booking-form.component';
import { NotificationService } from '../../notification.service';
import { TranslationService } from '../../services/translation.service';
import { cityRoutes } from '../../data/routes';

describe('BookingFormComponent', () => {
  let component: BookingFormComponent;
  let fixture: ComponentFixture<BookingFormComponent>;
  let translationService: TranslationService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, NoopAnimationsModule, BookingFormComponent],
      providers: [
        NotificationService, // Provide the real service for spying
        TranslationService, // Provide the real translation service
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(BookingFormComponent);
    component = fixture.componentInstance;
    translationService = TestBed.inject(TranslationService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Form Initialization and Data Flow', () => {
    it('should have an invalid form when initialized', () => {
      expect(component.bookingForm.valid).toBeFalsy();
    });

    it('should populate route dropdown with city options when "City Transfer" is selected', fakeAsync(() => {
      const transferTypeControl = component.bookingForm.get('transferType');
      const routeControl = component.bookingForm.get('route');

      transferTypeControl?.setValue('city');
      fixture.detectChanges();
      tick(); 

      expect(routeControl?.enabled).toBeTruthy();
      expect(component.availableRoutes().length).toBeGreaterThan(0);
      const hasNitraRoute = component.availableRoutes().some(r => r.value === 'BA-Nitra');
      expect(hasNitraRoute).toBe(true);
    }));
  });

  describe('Form Validation', () => {
    it('should require all mandatory fields', () => {
      const controls = component.bookingForm.controls;
      expect(controls['date'].hasError('required')).toBeTruthy();
      expect(controls['time'].hasError('required')).toBeTruthy();
      expect(controls['transferType'].hasError('required')).toBeTruthy();
      expect(controls['email'].hasError('required')).toBeTruthy();
      expect(controls['phone'].hasError('required')).toBeTruthy();
    });

    it('should validate email format with multiple edge cases', () => {
      const email = component.bookingForm.get('email');
      
      email?.setValue('test');
      expect(email?.hasError('missingAtSymbol')).toBeTruthy();

      email?.setValue('test@');
      expect(email?.hasError('missingDomain')).toBeTruthy();

      email?.setValue('test@domain');
      expect(email?.hasError('missingDomain')).toBeTruthy();

      email?.setValue('test@domain.');
      expect(email?.hasError('invalidFormat')).toBeTruthy();
      
      email?.setValue('test@domain.com');
      expect(email?.valid).toBeTruthy();
    });

    it('should validate phone format', () => {
        const phone = component.bookingForm.get('phone');
        
        phone?.setValue('invalid number');
        expect(phone?.hasError('pattern')).toBeTruthy();

        phone?.setValue('123456789');
        expect(phone?.valid).toBeTruthy();

        phone?.setValue('+421901234567');
        expect(phone?.valid).toBeTruthy();
    });
  });

  describe('Form Actions (Submit & Share)', () => {
    let notificationSpy: jest.SpyInstance;

    beforeEach(() => {
      const notificationService = TestBed.inject(NotificationService);
      notificationSpy = jest.spyOn(notificationService, 'show');
    });

    it('onSubmit should show error and mark all as touched if the form is invalid', async () => {
      const markAllAsTouchedSpy = jest.spyOn(component.bookingForm, 'markAllAsTouched');
      await component.onSubmit();
      const expectedMessage = translationService.translate('notification.form.error');
      expect(notificationSpy).toHaveBeenCalledWith(expectedMessage, 'error');
      expect(markAllAsTouchedSpy).toHaveBeenCalled();
    });
    
    it('shareBooking should show error if the form is invalid', async () => {
      await component.shareBooking();
      const expectedMessage = translationService.translate('notification.share.error.formInvalid');
      expect(notificationSpy).toHaveBeenCalledWith(expectedMessage, 'error');
    });

    it('onSubmit should show success and reset on valid submission', fakeAsync(() => {
      const bookingData = {
        date: '2024-12-24',
        time: '18:00',
        transferType: 'city',
        route: 'BA-Centrum',
        email: 'test@example.com',
        phone: '123456789'
      };
      component.bookingForm.setValue(bookingData);
      fixture.detectChanges();
      
      const routeLabel = cityRoutes.find(r => r.value === bookingData.route)!.label;
      const expectedMessage = translationService.translate('notification.form.successTemplate', { 
        date: bookingData.date, 
        time: bookingData.time, 
        routeLabel 
      });

      expect(component.bookingForm.valid).toBe(true);
      component.onSubmit();
      tick(1500); // for the simulated API call
      
      expect(notificationSpy).toHaveBeenCalledWith(expectedMessage, 'success');
      expect(component.bookingForm.get('date')?.value).toBeNull();
      expect(component.bookingForm.get('transferType')?.value).toBe('');
    }));
  });
});