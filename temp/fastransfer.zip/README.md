# FasTransfer VIP - Prémiová Preprava

![FasTransfer VIP Screenshot](https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=1200&h=630&fit=crop)

Elegantná a responzívna PWA (Progressive Web App) pre rezerváciu VIP prepravy, postavená na moderných webových technológiách. Aplikácia ponúka plynulý používateľský zážitok, inteligentného AI asistenta, plnú viacjazyčnú podporu a funguje aj v offline režime.

## ✨ Kľúčové Vlastnosti

*   **Moderný Tech Stack**: Postavené na **Angular (v20+)** so zoneless change detection pre maximálny výkon.
*   **Responzívny Dizajn**: Vizuálne atraktívne rozhranie vytvorené pomocou **Tailwind CSS**, optimalizované pre všetky zariadenia.
*   **Inteligentný AI Asistent**: Využíva **Google Gemini API** na spracovanie požiadaviek v prirodzenom jazyku a automatické vyplnenie rezervačného formulára.
*   **Viacjazyčná Podpora (i18n)**: Plná podpora pre slovenčinu, angličtinu a nemčinu s dynamickým prepínaním bez nutnosti obnovenia stránky.
*   **Progressive Web App (PWA)**:
    *   Inštalovateľná na domovskú obrazovku.
    *   Offline prístup vďaka Service Workeru.
    *   Notifikácie o stave siete.
*   **Optimalizácia Výkonu**: Strategické využitie `@defer` (lazy loading) pre bleskové načítanie a `NgOptimizedImage` pre optimálne LCP.
*   **SEO-Ready**: Kód je plne pripravený na Server-Side Rendering (SSR) pre maximálnu viditeľnosť vo vyhľadávačoch.

## 🚀 Nasadenie na Vercel

Táto aplikácia je navrhnutá pre jednoduché nasadenie na platformu [Vercel](https://vercel.com/).

### Kroky pre Nasadenie

1.  **Vytvorte si účet na Vercel**: Ak ešte nemáte účet, zaregistrujte sa na [vercel.com](https://vercel.com/signup). Odporúčame prepojenie s vaším GitHub, GitLab alebo Bitbucket účtom.

2.  **Vytvorte si Git repozitár**:
    *   Nahrajte tento projekt do vášho vlastného Git repozitára (napr. na GitHub).
    *   Uistite sa, že `vercel.json` súbor je v koreňovom adresári projektu.

3.  **Importujte projekt do Vercelu**:
    *   V dashboarde Vercelu kliknite na "Add New..." -> "Project".
    *   Vyberte Git repozitár, ktorý ste vytvorili v predchádzajúcom kroku.
    *   Vercel automaticky deteguje, že ide o statickú webovú stránku. **Nie je potrebná žiadna špeciálna konfigurácia zostavenia (build configuration).** Vercel bude servírovať obsah tak, ako je.

4.  **Nastavte Environmentálne Premenné**:
    *   Aby AI asistent fungoval, musíte nastaviť svoj Google Gemini API kľúč.
    *   V nastaveniach vášho projektu na Verceli prejdite do sekcie "Settings" -> "Environment Variables".
    *   Pridajte novú premennú:
        *   **Name**: `API_KEY`
        *   **Value**: `VLOZTE_SVOJ_GEMINI_API_KLUC_SEM`
    *   Uložte nastavenia. Vercel automaticky spustí nové nasadenie (re-deploy) s touto premennou.

5.  **Hotovo!**
    *   Po úspešnom nasadení bude vaša aplikácia dostupná na pridelenej Vercel doméne.

## 🛠️ Odporúčané VS Code Rozšírenia

Pre maximálnu produktivitu pri práci s týmto projektom odporúčame nainštalovať nasledujúce rozšírenia pre Visual Studio Code:

*   **Angular Language Service**: Poskytuje bohatú podporu pre editáciu Angular šablón.
*   **Tailwind CSS IntelliSense**: Autodopĺňanie, syntax highlighting a linting pre Tailwind CSS.
*   **ESLint**: Integruje ESLint priamo do editora.
*   **Prettier - Code formatter**: Automaticky formátuje kód pri uložení.
*   **GitLens — Git supercharged**: Vylepšuje prácu s Gitom.

## 📁 Štruktúra Projektu

```
.
├── src/
│   ├── components/       # Znovupoužiteľné Angular komponenty
│   ├── data/             # Statické dáta (trasy)
│   ├── directives/       # Vlastné direktívy
│   ├── pipes/            # Vlastné rúry (napr. translate)
│   ├── services/         # Služby (Gemini, notifikácie, preklady)
│   ├── app.component.html
│   └── app.component.ts
├── index.html            # Hlavný HTML súbor
├── index.tsx             # Vstupný bod aplikácie (bootstrap)
└── vercel.json           # Konfigurácia pre Vercel
```